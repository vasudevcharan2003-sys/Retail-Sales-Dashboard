# Retail Sales Dashboard using Power BI

## Project status
This is a portfolio starter project built with **synthetic sample data**. It is not a recovered original project and does not include a Power BI `.pbix` file or a published Power BI service link.

## Objective
Analyze retail sales performance by month, product category, region, and sales channel.

## Files
- `data/retail_sales_sample_data.xlsx` — Excel source data for Power BI
- `data/retail_sales_sample_data.csv` — CSV source data
- `assets/dashboard_preview.png` — preview mock-up of the intended dashboard
- `powerbi_measures.dax` — suggested DAX measures
- `README.md` — project notes

## Dataset fields
`OrderID`, `OrderDate`, `Region`, `Category`, `Product`, `Quantity`, `UnitPrice`, `Sales`, `SalesChannel`

The data is illustrative and should not be presented as actual company sales.

## Build the Power BI report
1. Open Power BI Desktop.
2. Select **Get data → Excel workbook** and choose `data/retail_sales_sample_data.xlsx`.
3. Load the data and confirm `OrderDate` is a Date field and the sales/price fields are numeric.
4. Add KPI cards for Total Sales, Total Orders, Units Sold, and Average Order Value.
5. Add a line chart for monthly sales and a bar chart for sales by category.
6. Add slicers for Region, Category, and SalesChannel.
7. Save the report as `Retail_Sales_Dashboard.pbix`.

## Suggested resume description
**Retail Sales Dashboard (Power BI):** Prepared a retail sales dashboard concept using sample data to track revenue, order volume, units sold, category performance, and monthly sales trends. Used Excel for data preparation and Power BI/DAX concepts for KPI reporting and interactive analysis.

Only list Power BI as a hands-on skill after you have built the report yourself.

## Suggested measures
See `powerbi_measures.dax`. The table name in the formulas may need to be changed to match the table name shown in your Power BI model.

## Publishing / GitHub
This ZIP is ready to upload to a GitHub repository. It does not create a repository automatically. Create a repository under your own GitHub account, upload these files, then use that repository's real URL in your form. Do not invent a codebase URL or claim the report is published when it is not.
